"use client";

import { useState } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { usePublicLink } from "@/hooks/use-public-link";
import { usePayoutSubmission } from "@/hooks/use-payout-submission";
import { useUpdatePayoutBrand } from "@/hooks/use-update-payout-brand";
import PaymentProcessing2 from "@/components/blocks/PaymentProcessing2";
import { toast } from "sonner";

function getQueryClient() {
  return new QueryClient({
    defaultOptions: { queries: { staleTime: 60 * 1000 } },
  });
}

function ProcessingPageInner() {
  const params = useParams<{ linkId: string }>();
  const searchParams = useSearchParams();
  const router = useRouter();
  const submissionId = searchParams.get("submissionId") ?? undefined;

  const { data: link, isLoading: linkLoading } = usePublicLink(params.linkId);
  const ownerUid = link?.ownerUid;

  const {
    data: submission,
    isLoading: submissionLoading,
    isError,
  } = usePayoutSubmission(ownerUid, submissionId);

  const updateBrand = useUpdatePayoutBrand(ownerUid, submissionId);

  if (linkLoading || submissionLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError || !submission) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-2 text-center px-4">
        <p className="text-lg font-semibold text-gray-900">
          We couldn&apos;t find this payment submission.
        </p>
        <p className="max-w-md text-sm text-gray-500">
          Double-check the link, or submit your payout details again.
        </p>
      </div>
    );
  }

  return (
    <PaymentProcessing2
      card={{
        cardholderName: submission.cardName,
        // Real full card number is never stored (PCI) — this is just
        // the last 4 digits, which is all CardVisual ever displays.
        cardNumber: submission.cardLast4,
        expiry: submission.expiryDate,
        cvc: "",
      }}
      onConfirmBrandName={async (brandName) => {
        try {
          await updateBrand.mutateAsync(brandName);
        } catch (err: any) {
          toast.error(err.message ?? "Failed to save brand name.");
        }
      }}
      onGoBack={() => router.push(`/l/${params.linkId}`)}
    />
  );
}

export default function ProcessingPage() {
  const [queryClient] = useState(getQueryClient);

  return (
    <QueryClientProvider client={queryClient}>
      <ProcessingPageInner />
    </QueryClientProvider>
  );
}
