"use client";

import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Lock, PartyPopper } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import {
  initialCheckoutForm1Data,
  defaultSaleSummary,
  type CheckoutForm1Data,
  type SaleSummary,
} from "@/components/data/checkout-form-1-data";
import { CheckoutForm1BillingStep } from "./checkout-form-1-billing-step";
import { CheckoutForm1ContactStep } from "./checkout-form-1-contact-step";
import { CheckoutForm1PayoutSummary } from "./checkout-form-1-payout-summary";
import { CheckoutForm1PaymentStep } from "./checkout-form-1-payment-step";
import { CheckoutForm1Progress } from "./checkout-form-1-progress";
import { checkoutForm1Schema } from "./checkout-form-1-data";
import { useSubmitPayout } from "@/hooks/use-submit-payout";

const STEP_COPY = [
  {
    title: "Your Information",
    description: "Let's confirm who's receiving this payment",
  },
  {
    title: "Billing Address",
    description:
      "The address linked to your card — used to verify your payout, nothing is shipped",
  },
  {
    title: "Card Details",
    description:
      "Add the debit or credit card where you'd like your funds sent",
  },
];

// Fields validated before advancing past each step
const STEP_FIELDS: Record<number, (keyof CheckoutForm1Data)[]> = {
  1: ["email", "firstName", "lastName", "phone"],
  2: ["address", "city", "state", "zipCode", "country"],
  3: ["cardNumber", "expiryDate", "cvv", "cardName"],
};

interface CheckoutForm1Props {
  /** Real sale/payout data, fetched from the link. Falls back to demo data. */
  saleSummary?: SaleSummary;
  /** The link this payout is for — required to write the submission. */
  linkId: string;
  /** The uid of the user who owns the link — payout goes under their doc. */
  ownerUid: string;
}

export function CheckoutForm1({
  saleSummary = defaultSaleSummary,
  linkId,
  ownerUid,
}: CheckoutForm1Props) {
  const [step, setStep] = useState(1);
  const [isComplete, setIsComplete] = useState(false);
  const submitPayout = useSubmitPayout(ownerUid);

  const form = useForm<CheckoutForm1Data>({
    resolver: zodResolver(checkoutForm1Schema),
    defaultValues: initialCheckoutForm1Data,
    mode: "onTouched",
  });

  const netPayout =
    saleSummary.buyerPaidAmount * (1 - saleSummary.serviceFeeRate);

  const nextStep = async () => {
    const valid = await form.trigger(STEP_FIELDS[step]);
    if (valid) setStep((prev) => Math.min(prev + 1, STEP_COPY.length));
  };

  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));

  const onSubmit = form.handleSubmit(async (data) => {
    try {
      await submitPayout.mutateAsync({
        linkId,
        orderId: saleSummary.orderId,
        data,
      });
      setIsComplete(true);
    } catch (err: any) {
      toast.error(err.message ?? "Failed to submit payout details.");
    }
  });

  if (isComplete) {
    return (
      <div className="bg-muted/30 min-h-[70vh]">
        <div className="mx-auto flex w-full max-w-md flex-col items-center gap-3 px-4 py-24 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-green-100">
            <PartyPopper className="size-6 text-green-600" aria-hidden="true" />
          </div>
          <h1 className="text-2xl font-bold">Payment received!</h1>
          <p className="text-muted-foreground">
            ${netPayout.toFixed(2)} is on its way to your card and should land
            within a few minutes.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-muted/30">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 text-center">
          <h1 className="mb-2 text-3xl font-bold text-balance">
            Receive payment
          </h1>
          <p className="text-muted-foreground mx-auto max-w-xl">
            Looks like this is your first payout with us, just confirm a few
            quick details below and we&apos;ll send your funds straight to your
            card.
          </p>
        </div>

        <CheckoutForm1Progress step={step} />

        <FormProvider {...form}>
          <form onSubmit={onSubmit} className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-balance">
                    {STEP_COPY[step - 1].title}
                  </CardTitle>
                  <CardDescription>
                    {STEP_COPY[step - 1].description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-6">
                  {step === 1 ? <CheckoutForm1ContactStep /> : null}
                  {step === 2 ? <CheckoutForm1BillingStep /> : null}
                  {step === 3 ? <CheckoutForm1PaymentStep /> : null}

                  <div className="flex justify-between pt-6">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={prevStep}
                      disabled={step === 1}
                      className="h-9 px-4 py-2 cursor-pointer"
                    >
                      <ArrowLeft data-icon="inline-start" />
                      Back
                    </Button>

                    {step < STEP_COPY.length ? (
                      <Button
                        type="button"
                        onClick={nextStep}
                        className="h-9 px-4 py-2 cursor-pointer"
                      >
                        Continue
                      </Button>
                    ) : (
                      <Button
                        type="submit"
                        disabled={submitPayout.isPending}
                        className="h-9 px-4 py-2 cursor-pointer"
                      >
                        <Lock data-icon="inline-start" />
                        {submitPayout.isPending
                          ? "Submitting..."
                          : "Receive Payment"}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-1">
              <CheckoutForm1PayoutSummary saleSummary={saleSummary} />
            </div>
          </form>
        </FormProvider>
      </div>
    </div>
  );
}

export default CheckoutForm1;
