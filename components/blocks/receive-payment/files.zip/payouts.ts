import { collection, doc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { CheckoutForm1Data } from "@/components/data/checkout-form-1-data";

export interface PayoutSubmissionInput {
  linkId: string;
  orderId: string;
  data: CheckoutForm1Data;
}

export interface PayoutSubmission {
  id: string;
  linkId: string;
  orderId: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  cardName: string;
  cardLast4: string;
  expiryDate: string;
  saveInfo: boolean;
}

/**
 * Writes a payout submission to users/{ownerUid}/payoutSubmissions/{id}.
 *
 * SECURITY: the full card number and CVV are intentionally NEVER written
 * to Firestore — only cardName, the last 4 digits, and expiryDate are
 * kept. Storing raw card numbers/CVVs in a database is a serious PCI-DSS
 * violation. If you need to actually move money later, integrate a real
 * payment processor (Stripe, etc.) — this only records the payout claim.
 */
export async function createPayoutSubmission(
  ownerUid: string,
  { linkId, orderId, data }: PayoutSubmissionInput,
): Promise<PayoutSubmission> {
  const ref = doc(collection(db, "users", ownerUid, "payoutSubmissions"));

  const cardLast4 = data.cardNumber.replace(/\s/g, "").slice(-4);

  const submission: Omit<PayoutSubmission, never> & { createdAt: unknown } = {
    id: ref.id,
    linkId,
    orderId,
    email: data.email,
    firstName: data.firstName,
    lastName: data.lastName,
    phone: data.phone,
    address: data.address,
    city: data.city,
    state: data.state,
    zipCode: data.zipCode,
    country: data.country,
    cardName: data.cardName,
    cardLast4,
    expiryDate: data.expiryDate,
    saveInfo: !!data.saveInfo,
    createdAt: serverTimestamp(),
  };

  await setDoc(ref, submission);
  return submission as PayoutSubmission;
}
